package butterfly;

/**
 *
 * @author Jake
 */
public interface IAudioPlayerComponent 
{
    
}
