package butterfly;

import ui.IAudioUI;

/**
 *
 * @author natec
 */
public interface IAudioController extends IAudioPlayerComponent{
    
    public void setUI(IAudioUI ui);
}
