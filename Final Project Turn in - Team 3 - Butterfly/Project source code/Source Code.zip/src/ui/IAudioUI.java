package ui;

import butterfly.IAudioController;

/**
 *
 * @author natec
 */
public interface IAudioUI {
    
    public void setController(IAudioController controller);
}
