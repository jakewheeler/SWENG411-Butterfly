package audio;

/**
 *
 * @author natec
 */
public interface INamedSongList extends ISongList
{    
    public String getName();
    
    public void setName(String name);
}
